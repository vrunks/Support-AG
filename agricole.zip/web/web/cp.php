<?php

include("config.php");

$_SESSION['dep'] = $_POST['dep'];


include 'index2.html';

?>

